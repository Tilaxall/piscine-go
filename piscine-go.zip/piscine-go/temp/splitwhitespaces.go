package main

import (
	"fmt"
)

func main() {
	str := "Hello how are you?"
	fmt.Println(SplitWhiteSpaces(str))
}

func SplitWhiteSpaces(str string) []string {
	Index := 0
	indexResultMass := 0
	//size := 1
	//resultMass := make([]string(indexResultMass))
	for index, key := range str {
		if key == ' ' || key == '\t' || key == '\n' {

			indexResultMass = indexResultMass + 1
		}
		Index = index
	}
	indexResultMass = indexResultMass + 1

	if str[0] == ' ' {
		indexResultMass--
	}
	if str[indexResultMass] == ' ' {
		indexResultMass--
	}

	fmt.Println(Index)

	for l := 0; l <= Index; l++ {
		if l != 0 && (str[l] == ' ' || str[l] == '\n' || str[l] == '\t') && (str[l-1] == ' ' || str[l-1] == '\n' || str[l-1] == '\t') {
			indexResultMass--
		}
	}

	//for h:=0; i< indexResultMass

	//fmt.Println(indexResultMass)
	//indexResultMass = indexResultMass + 1
	i := 0
	var tempStr string
	//var resultMass = [100]string{}
	resultMass := make([]string, indexResultMass)
	//fmt.Println(indexResultMass)
	for l := 0; l <= Index; l++ {
		if str[l] != ' ' && !(str[l] >= 0 && str[l] <= 31) {
			tempStr += string(str[l])
		}
		fmt.Println(tempStr)
		fmt.Println(indexResultMass)
		if str[l] == ' ' || l == Index && (l != 0 && (str[l-1] == ' ' || str[l-1] == '\n' || str[l-1] == '\t')) {
			for i > indexResultMass+1 {
				fmt.Println(tempStr)
				resultMass[i] = tempStr
				fmt.Println(tempStr)
				tempStr = ""
				break
			}
			i++
		}

	}
	//fmt.Println((resultMass))
	return resultMass
}
