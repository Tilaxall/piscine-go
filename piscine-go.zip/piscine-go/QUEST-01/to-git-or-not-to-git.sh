#!/bin/bash
curl https://api.github.com/users/tilaxall | jq '.id'
