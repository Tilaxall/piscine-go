package student

type Pilot struct {
	Name     string
	Life     float32
	Age      int
	Aircraft int
}

const AIRCRAFT1 = 1
