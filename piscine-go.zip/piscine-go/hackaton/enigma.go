package piscine

func Enigma(a ***int, b *int, c *******int, d ****int) {
	aa := ***a
	bb := *b
	cc := *******c
	dd := ****d

	***a = bb
	*b = dd
	*******c = aa
	****d = cc

}
