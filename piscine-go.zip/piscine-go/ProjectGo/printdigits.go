package main

import "fmt"

func main() {
	fmt.Println("0123456789")
}
