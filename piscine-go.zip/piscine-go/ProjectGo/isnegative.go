package main

import "fmt"

func IsNegative(nb int) {
	if nb >= 0 {
		fmt.Println("F")
	} else {
		fmt.Println("T")
	}
}

func main() {
	//IsNegative(9)
}


func IsNegative(nb int) {
	if nb >= 0 {
		z01.PrintRune("F")
	} else {
		z01.PrintRune("T")
	}