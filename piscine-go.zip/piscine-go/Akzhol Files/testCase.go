package main

import (
	"fmt"
)

func main() {
	fmt.Println(revCase("SplitWhiteSpaces function separates the words of a string?"))
}

func revCase(s string) string {
	str := []rune(s)
	//index := 13
	for index, key := range str {
		if (key >= 'n' && key <= 'z') || (key >= 'N' && key <= 'Z') {
			str[index] = key - 13
		}
		if (key >= 'a' && key <= 'm') || (key >= 'A' && key <= 'M') {
			str[index] = key + 13
		}
	}
	return string(str)
}
