package piscine

func FirstRune(s string) rune {
	byteStr := []rune(s)
	return byteStr[0]
}
