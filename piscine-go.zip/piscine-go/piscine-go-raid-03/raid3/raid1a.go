package main

import (
	"fmt"
	"os"

	"github.com/01-edu/z01"
)

func main() {
	index := 0
	arguments := os.Args[1:]
	for i := range arguments {
		index = i + 1
	}
	if index < 2 || index > 2 {
		fmt.Println("Error")
		os.Exit(0)
	}
	number1 := BasicAtoi(arguments[0])
	number2 := BasicAtoi(arguments[1])

	Raid1a(number1, number2)
}

func BasicAtoi(s string) int {
	res := 0
	for _, val := range s {
		a := 0
		for i := '1'; i <= val; i++ {
			a++
		}
		res = res*10 + a
	}
	return res
}

func Raid1a(x, y int) {
	if x <= 0 || y <= 0 {
	} else {
		if x == 1 && y != 1 {
			for j := 1; j <= y; j++ {
				if j == y {
					z01.PrintRune(10)
				}
				if j == 1 || j == y {
					z01.PrintRune('o')

				} else {
					z01.PrintRune(10)
					z01.PrintRune('|')

				}
			}
		} else if x != 1 && y == 1 {
			for i := 1; i <= x; i++ {
				if i == 1 || i == x {
					z01.PrintRune('o')
				} else {
					z01.PrintRune('-')
				}
			}
		} else if x == 1 && y == 1 {
			z01.PrintRune('o')
		} else {
			for i := 1; i <= x; i++ {
				if i == 1 || i == x {
					z01.PrintRune('o')
				} else {
					z01.PrintRune('-')
				}
			}
			z01.PrintRune('\n')
			for j := 1; j <= y-2; j++ {
				for k := 1; k <= x; k++ {
					if k == 1 || k == x {
						z01.PrintRune('|')
					} else {
						z01.PrintRune(' ')
					}
				}
				z01.PrintRune(10)
			}
			for i := 1; i <= x; i++ {
				if i == 1 || i == x {
					z01.PrintRune('o')
				} else {
					z01.PrintRune('-')
				}

			}
		}
		z01.PrintRune('\n')
	}
}
