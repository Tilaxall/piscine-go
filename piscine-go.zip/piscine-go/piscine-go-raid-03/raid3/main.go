package main

import (
	"bufio"
	"fmt"
	"os"
)

func main() {

	reader := bufio.NewReader(os.Stdin)
	var output []rune
	for {
		input, _, err := reader.ReadRune()
		if err != nil {
			break
		}
		output = append(output, input)
	}
	if (output == nil) || (output[0] != 'o' && output[0] != '/' && output[0] != 'A') {
		fmt.Println("Not a Raid function")
		return
	}
	determineInput(output)

}

func counter(output []rune) (x, y int) {
	countX := 0
	countY := 0
	flag := true
	for _, s := range output {
		if s == '\n' {
			countY++
			flag = false
		} else {
			if flag == true {
				countX++
			}
		}
	}
	return countX, countY
}

func determineInput(output []rune) {
	length, width := counter(output)
	rightUpperCorner := length - 1
	lowerLeftCorner := rightUpperCorner * width
	rightLeftCorner := lowerLeftCorner + rightUpperCorner
	arrOfRaids := []string{"raid1a", "raid1b", "raid1c", "raid1d", "raid1e"}
	if length == 1 && width == 1 && output[0] == 'A' {
		fmt.Printf("[%v] [%v] [%v] || [%v] [%v] [%v] || [%v] [%v] [%v]", arrOfRaids[2], length, width, arrOfRaids[3], length, width, arrOfRaids[4], length, width)
	} else if length > 1 && width == 1 && output[0] == 'A' {
		fmt.Printf("[%v] [%v] [%v] || [%v] [%v] [%v]", arrOfRaids[3], length, width, arrOfRaids[4], length, width)
	} else if length == 1 && width > 1 && output[0] == 'A' {
		fmt.Printf("[%v] [%v] [%v] || [%v] [%v] [%v]", arrOfRaids[2], length, width, arrOfRaids[4], length, width)
	} else if output[0] == 'o' {
		fmt.Printf("[%v] [%v] [%v]", arrOfRaids[0], length, width)
	} else if output[0] == '/' {
		fmt.Printf("[%v] [%v] [%v]", arrOfRaids[1], length, width)
	} else if output[0] == 'A' && output[rightUpperCorner] == 'A' && output[lowerLeftCorner] == 'C' && output[rightLeftCorner] == 'C' {
		fmt.Printf("[%v] [%v] [%v]", arrOfRaids[2], length, width)
	} else if output[0] == 'A' && output[rightUpperCorner] == 'C' && output[lowerLeftCorner] == 'A' && output[rightLeftCorner] == 'C' {
		fmt.Printf("[%v] [%v] [%v]", arrOfRaids[3], length, width)
	} else if output[0] == 'A' && output[rightUpperCorner] == 'C' && output[lowerLeftCorner] == 'C' && output[rightLeftCorner] == 'A' {
		fmt.Printf("[%v] [%v] [%v]", arrOfRaids[4], length, width)
	}
	fmt.Println()
}
