package main

//NormalizeStr converts dots to 0 in place and checks if all char are valid numbers
func NormalizeStr(str *string, args *[]string, argsIndex int) (err bool) {
	strLen := 0
	for index := range *str {
		strLen = index + 1
	}
	if strLen != 9 {
		return true
	}

	normalized := ""
	for _, char := range *str {
		if char == '.' {
			normalized += "0"
		} else if char < '1' || char > '9' {
			return true
		} else {
			_, str := castRune(char)
			normalized += str
		}
	}
	(*args)[argsIndex] = normalized
	return false
}

//PutArgsToTable puts arguments to main table
func PutArgsToTable(args *[]string, table *[9][9]int) [9][9]int {
	for rowIndex, rowStr := range *args {
		for colIndex, char := range rowStr {
			(*table)[rowIndex][colIndex], _ = castRune(char)
		}
	}
	return *table
}

func castRune(char rune) (int, string) {
	var num int
	var str string
	switch char {
	case '1':
		num, str = 1, "1"
	case '2':
		num, str = 2, "2"
	case '3':
		num, str = 3, "3"
	case '4':
		num, str = 4, "4"
	case '5':
		num, str = 5, "5"
	case '6':
		num, str = 6, "6"
	case '7':
		num, str = 7, "7"
	case '8':
		num, str = 8, "8"
	case '9':
		num, str = 9, "9"
	}
	return num, str
}
